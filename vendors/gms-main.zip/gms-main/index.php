<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TMU Transportation Request System</title>
    <script src="/gms/assets/js/vue.global.js"></script>
    <!-- <link href="/gms/assets/css/daisy.css" rel="stylesheet" type="text/css" /> -->
    <script src="/gms/assets/js/tailwind.js"></script>
    <!-- <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'> -->
    <style>
        /* Additional custom styles */
        body {
            font-family: 'figtree', sans-serif;
        }

        .bg-[#036d21] {
            background-color: #f8f4f3;
        }
    </style>
</head>

<body>
    <div class="font-sans text-gray-900 antialiased">
        <div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-[#036d21]">
            <div>
                <a href="/">
                    <h2 class="font-bold text-3xl"><span class="bg-[#036d21] text-white px-2 rounded-md">TMU Transportation Request System</span></h2>
                </a>
            </div>

            <div class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg">
                <?php
                include("config.php");
                ob_start();
                include("auth.php");
                if ($_SESSION['iuid']) {
                    if ($_SESSION['iupriv'] == 1)
                        header("location: dashboard.php");
                    elseif ($_SESSION['iupriv'] == 0)
                        header("location: dashboard.php");
                    else
                        header("location: dashboard.php");
                    ob_end_flush();;
                }
                if ($_POST['username'] && $_POST['password']) {
                    if ($_SESSION['logctr'] > 10)
                        $errmsg = "Maximum login attempts exceeded";
                    else {
                        $username = $db->real_escape_string($_POST['username']);
                        $password = $db->real_escape_string($_POST['password']);

                        $result = $db->query("SELECT * FROM users WHERE username='$username'");
                        if ($row = $result->fetch_assoc()) {
                            if (password_verify($password, $row['userpass'])) {
                                $_SESSION['iuid'] = $row['userid'];
                                $_SESSION['ifname'] = $row['fname'];
                                $_SESSION['iupriv'] = $row['userprivilege'];
                                if ($_POST['chkremember'] == '1') {
                                    $_SESSION['iremember'] = 1;
                                    setcookie('hrem', $_SESSION['iuid'], time() + (3600 * 60), '/');
                                    setcookie('hrei', base64_encode($_SESSION['ifname']), time() + (3600 * 60), '/');
                                    setcookie('hrep', base64_encode($_SESSION['iupriv']), time() + (3600 * 60), '/');
                                }
                                header("location: index.php");
                                ob_end_flush();;
                            } else {
                                $errmsg = "Incorrect password";
                            }
                        } elseif ($row['userstatus'] != 0) {
                            $errmsg = "User is not allowed to log in";
                        } else {
                            if (!$_SESSION['logctr'])
                                $_SESSION['logctr'] = 0;
                            $_SESSION['logctr'] = $_SESSION['logctr'] + 1;
                            if ($_SESSION['logctr'] > 10)
                                $errmsg = "Maximum login attempts exceeded";
                            $errmsg = "Incorrect username";
                        }
                    }
                }
                ?>
                <form method="post">
                    <div class="pb-3">
                        <center>
                            <span class="text-2xl font-semibold">
                                <div>
                                    <a href="#">
                                        <img src="/gms/assets/img/mmwghlogo.png" alt="Logo" class="w-40 h-40">
                                    </a>
                                </div>
                            </span>
                        </center>
                    </div>

                    <div>
                        <label class="block font-medium text-sm text-gray-700" for="username" value="Username" />
                        <input type='text' name='username' placeholder='Username' class="w-full rounded-md py-2.5 px-4 border text-sm outline-[#036d21]" />
                    </div>


                    <div class="mt-4">
                        <label class="block font-medium text-sm text-gray-700" for="password" value="Password" />
                        <div class="relative">
                            <input id="password" type='password' name='password' placeholder='Password' required autocomplete='current-password' class='w-full rounded-md py-2.5 px-4 border text-sm outline-[#036d21]'>
                            <div class="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5">
                                <button type="button" id="togglePassword" class="text-gray-500 focus:outline-none focus:text-gray-600 hover:text-gray-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;">
                                        <path d="M12 4.998c-1.836 0-3.356.389-4.617.971L3.707 2.293 2.293 3.707l3.315 3.316c-2.613 1.952-3.543 4.618-3.557 4.66l-.105.316.105.316C2.073 12.382 4.367 19 12 19c1.835 0 3.354-.389 4.615-.971l3.678 3.678 1.414-1.414-3.317-3.317c2.614-1.952 3.545-4.618 3.559-4.66l.105-.316-.105-.316c-.022-.068-2.316-6.686-9.949-6.686zM4.074 12c.103-.236.274-.586.521-.989l5.867 5.867C6.249 16.23 4.523 13.035 4.074 12zm9.247 4.907-7.48-7.481a8.138 8.138 0 0 1 1.188-.982l8.055 8.054a8.835 8.835 0 0 1-1.763.409zm3.648-1.352-1.541-1.541c.354-.596.572-1.28.572-2.015 0-.474-.099-.924-.255-1.349A.983.983 0 0 1 15 11a1 1 0 0 1-1-1c0-.439.288-.802.682-.936A3.97 3.97 0 0 0 12 7.999c-.735 0-1.419.218-2.015.572l-1.07-1.07A9.292 9.292 0 0 1 12 6.998c5.351 0 7.425 3.847 7.926 5a8.573 8.573 0 0 1-2.957 3.557z"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                    <!--
                    <div class="mt-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="formCheck-1" name="chkremember" value="1" checked>
                            <label class="form-check-label" for="formCheck-1">Remember Me</label>
                        </div>
                    </div> -->

                    <div class="mt-4">
                        <button class="bg-[#036d21] hover:bg-green-900 text-white font-bold py-2 px-4 rounded w-full" type="submit">Login</button>
                    </div>
                    <!--
                    <div class="text-center mt-4">
                        <a href="forgotpassword">Forgot Password</a>
                    </div> -->
                </form>
            </div>
        </div>
    </div>

    <script>
        const passwordInput = document.getElementById('password');
        const togglePasswordButton = document.getElementById('togglePassword');

        togglePasswordButton.addEventListener('click', () => {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
        });
    </script>

</body>

</html>