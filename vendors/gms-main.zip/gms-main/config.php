<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
date_default_timezone_set("Asia/Manila");
$dbhost = "localhost";
$dbname = "gms";
$dbuser = "root";
$dbpass = "";

// Establish database connection
$db = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

// Check for connection errors
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
