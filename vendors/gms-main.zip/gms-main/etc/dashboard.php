<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TMU Transportation Request System</title>
    <script src="/gms/assets/js/vue.global.js"></script>
    <!-- <link href="/gms/assets/css/daisy.css" rel="stylesheet" type="text/css" /> -->
    <script src="/gms/assets/js/tailwind.js"></script>
</head>

<body class="bg-gray-100 ">
    <div id="app" class="bg-white min-h-screen flex flex-col">
        <nav style="background-color: #036d21;">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between h-16">
                    <div class="flex items-center">
                        <img class="h-12 w-auto" src="/gms/assets/img/mmwghlogo.png" alt="Logo">
                        <div class="hidden sm:ml-6 space-x-8 sm:flex">
                            <a href="/gms/dashboard.php" class="text-white bg-green-700 px-3 py-2 rounded-md text-sm font-medium">Home</a>
                            <a href="/gms/" class="text-white hover:bg-green-700 px-3 py-2 rounded-md text-sm font-medium">About</a>
                            <a href="/gms/" class="text-white hover:bg-green-700 px-3 py-2 rounded-md text-sm font-medium">Contact</a>
                        </div>
                    </div>
                    <div class="hidden sm:flex sm:items-center sm:ml-6">
                        <a href="/gms/logout.php" class="text-white hover:bg-green-700 px-3 py-2 rounded-md text-sm font-medium">Logout</a>
                    </div>
                    <div class="-mr-2 flex items-center sm:hidden">
                        <button @click="toggleMenu" type="button" class="bg-green-600 inline-flex items-center justify-center p-2 rounded-md text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-green-600 focus:ring-white" aria-controls="mobile-menu" aria-expanded="false">
                            <span class="sr-only">Open main menu</span>
                            <svg class="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
                            </svg>
                            <svg class="hidden h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
            <div v-if="state.isMenuOpen" id="mobile-menu">
                <div class="px-2 pt-2 pb-3 space-y-1">
                    <a href="#" class="text-white block px-3 py-2 rounded-md text-base font-medium">Home</a>
                    <a href="#" class="text-white block px-3 py-2 rounded-md text-base font-medium">About</a>
                    <a href="#" class="text-white block px-3 py-2 rounded-md text-base font-medium">Contact</a>
                    <a href="#" class="text-white block px-3 py-2 rounded-md text-base font-medium">Logout</a>
                </div>
            </div>
        </nav>
        <div class="container mx-auto py-8 px-4 sm:px-6 lg:px-8 flex-grow">
            <form @submit.prevent="submitForm" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                <div class="my-4 flex flex-col">
                    <label class="block text-gray-700 text-sm font-semibold mb-2">Destination</label>
                    <input v-model="state.destination" placeholder="Destination" class="shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                </div>
                <div class="my-4 flex flex-col">
                    <label class="block text-gray-700 text-sm font-semibold mb-2">Select Option</label>
                    <select v-model="state.selectedOption" class="shadow border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        <option value="Home Conduction">Home Conduction</option>
                        <option value="Transfer">Transfer</option>
                        <option value="Referral">Referral</option>
                        <option value="Others">Others</option>
                    </select>
                </div>
                <div v-if="state.selectedOption == 'Others'" class="my-4 flex flex-col">
                    <label class="block text-gray-700 text-sm font-semibold mb-2">Others</label>
                    <input v-model="state.others" placeholder="Others" class="shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                </div>
                <hr class="mt-4 mb-10">
                <p class="font-bold text-xl">Passengers</p>
                <hr class="mb-10">
                <div class="invisible md:visible  grid grid-cols-1 md:grid-cols-6 lg:grid-cols-12 gap-4 my-2">
                    <div class="md:col-span-2 lg:col-span-4 flex flex-col">
                        <label class="block text-gray-700 text-sm font-semibold mb-2">Passenger Name</label>
                    </div>
                    <div class="md:col-span-1 lg:col-span-2 flex flex-col">
                        <label class="block text-gray-700 text-sm font-semibold mb-2">Ward Name</label>
                    </div>
                    <div class="md:col-span-2 lg:col-span-5 flex flex-col">
                        <label class="block text-gray-700 text-sm font-semibold mb-2">Address</label>
                    </div>
                </div>
                <div v-for="(input, index) in state.inputs" :key="index" class="grid grid-cols-1 md:grid-cols-6 lg:grid-cols-12 gap-4 my-2">
                    <div class="md:col-span-2 lg:col-span-4 flex flex-col">
                        <input v-model="input.passengers" placeholder="Passenger Name" class="shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                    </div>
                    <div class="md:col-span-1 lg:col-span-2 flex flex-col">
                        <input v-model="input.ward" placeholder="Ward Name" class="shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                    </div>
                    <div class="md:col-span-2 lg:col-span-5 flex flex-col">
                        <input v-model="input.address" placeholder="Address" class="shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                    </div>
                    <button type="button" @click="removeInput(index)" class="lg:col-span-1 bg-red-500 text-white rounded ">Remove</button>
                </div>
                <div class="flex justify-end m-4">
                    <button type="button" @click="addInput" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline mr-2">Add Passenger</button>
                    <!-- <button type="button" @click="removeLastInput" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Remove Last Input</button> -->
                </div>
                <hr class="mb-10">
                <p class="font-bold text-xl">Escorts</p>
                <hr class="mb-10">
                <div class="invisible md:visible grid grid-cols-1  md:grid-cols-6 lg:grid-cols-12 gap-4 my-2">
                    <div class="col-span-1 md:col-span-3 lg:col-span-6 flex flex-col">
                        <label class="text-gray-700 text-sm font-semibold mb-2 block">Escort Name</label>
                    </div>
                    <div class="col-span-1 md:col-span-2 lg:col-span-5 flex flex-col">
                        <label class="text-gray-700 text-sm font-semibold mb-2 block">Escort Position</label>
                    </div>
                </div>

                <div v-for="(escort, index) in state.inputs_escort" :key="'escort_' + index" class="grid grid-cols-1 md:grid-cols-6 lg:grid-cols-12 gap-4 my-2">
                    <div class="col-span-1 md:col-span-3 lg:col-span-6 flex flex-col">
                        <input v-model="escort.escort_name" placeholder="Escort Name" class="shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                    </div>
                    <div class="col-span-1 md:col-span-2 lg:col-span-5 flex flex-col">

                        <input v-model="escort.position" placeholder="Escort Position" class="shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                    </div>
                    <button type="button" @click="removeEscortInput(index)" class="lg:col-span-1 bg-red-500 text-white rounded ">Remove</button>
                </div>
                <div class="flex justify-end m-4">
                    <button type="button" @click="addEscortInput" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline mr-2">Add Escort</button>
                    <!-- <button type="button" @click="removeLastEscortInput" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Remove Last Escort</button> -->
                </div>
                <input type="submit" value="Save" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline mr-2">
            </form>
        </div>
        <footer style="background-color: #036d21;">
            <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                <div class="flex justify-center space-x-6">
                    <a href="#" class="text-white hover:text-gray-200">Privacy Policy</a>
                    <a href="#" class="text-white hover:text-gray-200">Terms of Service</a>
                    <a href="#" class="text-white hover:text-gray-200">Contact Us</a>
                </div>
            </div>
        </footer>
    </div>

    <script>
        const {
            createApp,
            reactive
        } = Vue

        createApp({
            setup() {
                const state = reactive({
                    isMenuOpen: false,
                    destination: '',
                    selectedOption: '',
                    others: '',
                    inputs: [{
                        passengers: '',
                        ward: '',
                        address: ''
                    }, ],
                    inputs_escort: [{
                        escort_name: '',
                        position: '',
                    }, ],
                })

                const toggleMenu = () => {
                    state.isMenuOpen = !state.isMenuOpen
                }
                const addInput = () => {
                    state.inputs.push({
                        passengers: '',
                        ward: '',
                        address: ''
                    });
                };

                const removeInput = (index) => {
                    state.inputs.splice(index, 1);
                };

                // const removeLastInput = () => {
                //     if (state.inputs.length > 0) {
                //         state.inputs.pop();
                //     }
                // };
                const submitForm = () => {
                    state.inputs = state.inputs.filter(input => input.passengers.trim() !== '' && input.passengers !== '');
                    state.inputs_escort = state.inputs_escort.filter(input => input.escort_name.trim() !== '' && input.escort_name !== '');
                    console.log('Passenger Form submitted!');
                    // Handle form submission logic here
                };

                const addEscortInput = () => {
                    state.inputs_escort.push({
                        escort_name: ''
                    });
                };

                const removeEscortInput = (index) => {
                    state.inputs_escort.splice(index, 1);
                };

                // const removeLastEscortInput = () => {
                //     if (state.inputs_escort.length > 0) {
                //         state.inputs_escort.pop();
                //     }
                // };
                const submitEscortForm = () => {
                    console.log('Escort Form submitted!');
                    // Handle form submission logic here for escort form
                };

                return {
                    state,
                    toggleMenu,
                    addInput,
                    removeInput,
                    // removeLastInput,
                    submitForm,
                    addEscortInput,
                    removeEscortInput,
                    // removeLastEscortInput,
                    submitEscortForm,
                }
            }
        }).mount('#app')
    </script>
</body>

</html>