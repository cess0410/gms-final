<?php
include('config.php');
include('Calendar.php');

?>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <script src="/gms/assets/js/vue.global.js"></script>
    <script src="/gms/assets/js/tailwind.js"></script>
    <style>
        /* Additional custom styles */
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .calendar-container {
            width: 100%;
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            overflow: hidden;
        }

        .month-year {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            margin: 20px 0;
            color: #343a40;
        }

        .days {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 2px;
        }

        .day_name,
        .day_num {
            text-align: center;
            padding: 15px;
            border: 1px solid #dee2e6;
        }

        .day_name {
            background-color: #f2f2f2;
            font-weight: bold;
            color: #495057;
        }

        .selected {
            background-color: #007bff;
            color: #fff;
        }

        .ignore {
            color: #ced4da;
        }
    </style>
</head>

<body>
    <div class="font-sans text-gray-900 antialiased">
        <div class="min-h-screen flex flex-col pt-24  items-center  bg-[#036d21]">
            <div>
                <a href="/">
                    <h2 class="font-bold text-3xl"><span class="bg-[#036d21] text-white px-2 rounded-md">IMIS Pharmacy System</span></h2>
                </a>
            </div>

            <div class="w-full  mt-6 pb-24 px-24 bg-white shadow-md overflow-hidden sm:rounded-lg">
                <div class="table-responsive">
                    <?php
                    $sql = "SELECT 
                    s.id,
                    s.specialty,
                    DATE(i.consultdate) AS date,
                    COUNT(*) AS inquiry_count
                FROM tblinquiry AS i
                JOIN specialties AS s ON i.specialty = s.id
                GROUP BY s.specialty, DATE(i.consultdate)";

                    $result = $db->query($sql);
                    if ($result === false) {
                        die("Error executing query: " . $db->error);
                    }
                    $results = $result->fetch_all(MYSQLI_ASSOC);

                    $procdate = $_GET['date'];
                    $events = [];

                    foreach ($results as $result) {
                        $date = date("m-d-Y", strtotime($result['date']));
                        $specialty = $result['specialty'];
                        $inquiry_count = $result['inquiry_count'];
                        $id = $result['id'];


                        $eventTitle = "<a onclick='eventCall($id)'>$specialty ($inquiry_count)</a><br>";

                        if (!isset($events[$date])) {
                            $events[$date] = [];
                        }
                        $events[$date][] = ["title" => $eventTitle];
                    }


                    $eventss = [
                        "11-23-2024" => [
                            ["title" => "<a onclick='eventCall(1)'>Birthday Party (10)</a><br>"],
                            ["title" => "<a onclick='eventCall(2)'>Birthday Party (10)</a><br>"],
                            ["title" => "<a onclick='eventCall(3)'>Birthday Party (10)</a><br>"],
                            ["title" => "<a onclick='eventCall(4)'>Birthday Party (10)</a><br>"],
                        ],
                        "05-14-2024" => [
                            ["title" => "Meeting"],
                        ],
                    ];
                    print_r($eventss);
                    echo "<br>";
                    echo "<br>";
                    echo "<br>";
                    echo "<br>";
                    print_r($events);
                    $calendar = new Calendar($procdate, $events);
                    echo $calendar;
                    ?>
                </div>
            </div>
        </div>

        <script>
            const passwordInput = document.getElementById('password');
            const togglePasswordButton = document.getElementById('togglePassword');

            togglePasswordButton.addEventListener('click', () => {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
            });

            function eventCall(id) {
                alert("Event Clicked" + id);
            }
        </script>

</body>

</html>