<!DOCTYPE html>
<html>
<head><title>Quick Search</title>


        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
        <link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="screen">
       



<?php include('config.php');?>
</head>

	
<script src="js/jquery-1.7.2.min.js" type="text/javascript"></script>

<script type="text/javascript" src="js/books.js" ></script>
	
	
		