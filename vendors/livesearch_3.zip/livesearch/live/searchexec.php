<?php
//Get our database abstraction file
require('connection.php');

if (isset($_GET['search']) && $_GET['search'] != '') {
	//Add slashes to any quotes to avoid SQL problems.
	$search = $_GET['search'];
	$result3 = mysql_query("SELECT * FROM member where fname like('" .$search . "%')");
	while($row3 = mysql_fetch_array($result3))
	{
		echo '<a href=home.php?id=' . $row3['mem_id'] . '>' . $row3['fname'] . "</a>\n";	
	}
}
?>