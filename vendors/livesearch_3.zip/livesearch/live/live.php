<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<script language="JavaScript" type="text/javascript" src="search.js"></script>
<style type="text/css">
body{
font-family:Arial, Helvetica, sans-serif;
}
#main{
padding:15px;
margin:0 auto;
width: 265px;
border:2px double gray;
}
#layer2{
	width:262px;
	border:1px solid gray;
	margin-top: -2px;
	border-bottom-width: 0px;
}
#layer2 a{
	text-decoration:none;
	text-transform:capitalize;
	padding:5px;
}
.suggest_link{
background-color:#fff;
border-bottom:1px solid gray;
}
.small{
background-color:#fff;
border-bottom:1px solid gray;
}
.suggest_link_over{
background-color:#fff;
border-bottom:1px solid gray;
}
.suggest_link:hover{
background-color:#6d84b4;
border-bottom:1px solid gray;
}
.suggest_link_over:hover{
background-color:#6d84b4;
border-bottom:1px solid gray;
}
#amots{
	padding:5px;
	border-radius:none;
	width:250px;
	border:2px solid gray;
	background: url("search.png") no-repeat scroll right 0 transparent;
}
</style>
</head>

<body>
<div id="main">
Search Here:<br />
<input type="text" id="amots" name="amots" onKeyUp="bleble();" autocomplete="off"/>
<div id="layer2"></div>
<br />
<table width="262" border="1px" cellpadding="0" cellspacing="0">
<tr>
<td colspan="2">List of Names to Search </td>
</tr>
<?php
require_once('connection.php');
$result3 = mysql_query("SELECT * FROM member");
while($row3 = mysql_fetch_array($result3))
{ 

  echo '<tr>';
    echo '<td width="44">Name</td>';
    echo '<td width="192">'.$row3['fname'].' '.$row3['lname'].'</td>';
  echo '</tr>';
}
?>
</table>

<div>
</body>
</html>
