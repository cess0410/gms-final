<?php
include('header.php');
?>
<body>
<div class="wrapper">
<a class="btn btn-primary"  href="add_schedule.php">  <i class="icon-arrow-left icon-large"></i>&nbsp;Back</a>
<br>
<br>
<div class="alert alert-error">
  <a class="close" data-dismiss="alert" href="#">�</a>
  <h4 class="alert-heading">Warning!</h4>
  Best check yo self, you're not...<?php echo $teacher_n; ?>
</div>


</div>

</body>
</html>