

			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.pic2').qtip({
			content: 'Click to View Larger Image',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.news').qtip({
			content: 'News and Events',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>

			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.about').qtip({
			content: 'Click here to view About CHMSC',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.calendar').qtip({
			content: 'Click here to view Caledar of Events',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	

			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.site').qtip({
			content: 'Click here to View Site Map',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	

			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.facebook').qtip({
			content: 'Like Us on Facebook',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
		
						<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('#read').qtip({
			content: 'Click here to read more Information',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
					<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.admin').qtip({
			content: 'click here to login Administrator',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
						<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.today').qtip({
			content: 'Today is <?php $Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
		
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.help').qtip({
			content: 'Click Here to View Help',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
		
		
